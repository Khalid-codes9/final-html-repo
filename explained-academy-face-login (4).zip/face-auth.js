// Face login for Explained Academy.
// Registration: the candidate does a short live camera check and we keep a face template
// (128 numbers made from their face, not a picture). Exam login: the same check, compared to that template.
// Everything runs in the browser with face-api; the camera picture itself never leaves the device.
// The camera only works on an https:// page (or localhost).
(function () {
    var LIB = "https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.13/dist/face-api.js";
    var MODELS = "https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.13/model/";
    var MATCH = 0.5;         // camera vs saved template: lower is stricter
    var PHOTO_MATCH = 0.6;   // camera vs passport photo: photos are older and lower quality, so a little looser
    var TIMEOUT = 60;        // seconds the candidate has to finish the camera check
    var TURN = 0.13;         // how far the head must turn each way (0.5 = facing the camera)
    var loading = null;

    function load() {
        if (loading) return loading;
        loading = new Promise(function (ok, fail) {
            if (window.faceapi) return ok();
            var s = document.createElement("script"); s.src = LIB; s.onload = ok;
            s.onerror = function () { fail(new Error("Face check could not load. Check your internet connection and try again.")); };
            document.head.appendChild(s);
        }).then(function () {
            var n = faceapi.nets;
            return faceapi.tf.ready().then(function () {
                return Promise.all([n.tinyFaceDetector.loadFromUri(MODELS), n.faceLandmark68Net.loadFromUri(MODELS), n.faceRecognitionNet.loadFromUri(MODELS)]);
            });
        });
        loading.catch(function () { loading = null; });   // allow a retry after a network error
        return loading;
    }

    function round(d) { return Array.prototype.map.call(d, function (x) { return Math.round(x * 10000) / 10000; }); }
    function distance(a, b) {
        if (!a || !b || a.length !== b.length) return Infinity;
        var s = 0; for (var i = 0; i < a.length; i++) { var t = a[i] - b[i]; s += t * t; }
        return Math.sqrt(s);
    }
    function average(list) {
        return round(list[0].map(function (_, i) { return list.reduce(function (s, d) { return s + d[i]; }, 0) / list.length; }));
    }
    // 0.5 when facing the camera, smaller or larger as the head turns
    function yaw(lm) {
        var p = lm.positions, l = p[0].x, r = p[16].x;
        return (p[30].x - l) / (r - l);
    }

    // Face template from a photo (an <img> element).
    // Passport photos are tight close-ups, which the fast detector often misses, so the photo gets a border
    // and several detector sizes are tried, then the slower, more accurate detector as a last resort.
    function fromImage(img) {
        var canvas;
        function detect(opts) { return faceapi.detectAllFaces(canvas, opts).withFaceLandmarks().withFaceDescriptors(); }
        function attempt(tries) {
            if (!tries.length) return Promise.resolve([]);
            return tries[0]().then(function (r) { return r.length ? r : attempt(tries.slice(1)); });
        }
        return load().then(function () { return img.decode ? img.decode().catch(function () {}) : null; }).then(function () {
            var w = img.naturalWidth || img.width, h = img.naturalHeight || img.height, pad = Math.round(Math.max(w, h) * 0.35);
            canvas = document.createElement("canvas"); canvas.width = w + pad * 2; canvas.height = h + pad * 2;
            var c = canvas.getContext("2d"); c.fillStyle = "#808080"; c.fillRect(0, 0, canvas.width, canvas.height); c.drawImage(img, pad, pad, w, h);
            var tiny = function (size) { return function () { return detect(new faceapi.TinyFaceDetectorOptions({ inputSize: size, scoreThreshold: 0.3 })); }; };
            return attempt([tiny(416), tiny(608), tiny(320), function () {
                return faceapi.nets.ssdMobilenetv1.loadFromUri(MODELS).then(function () { return detect(new faceapi.SsdMobilenetv1Options({ minConfidence: 0.3 })); });
            }]);
        }).then(function (r) {
            if (!r.length) throw new Error("We could not find a face in your passport photo. Please use a clear, front-facing photo with your whole face showing.");
            // Use the biggest face; only refuse if a second face is nearly as big (a group photo)
            r.sort(function (a, b) { return b.detection.box.area - a.detection.box.area; });
            if (r.length > 1 && r[1].detection.box.area > r[0].detection.box.area * 0.5) throw new Error("There is more than one face in your passport photo. Please use a photo of only you.");
            return round(r[0].descriptor);
        });
    }

    var css = ".eaf-wrap{position:fixed;inset:0;z-index:4000;display:flex;align-items:center;justify-content:center;padding:16px;overflow:auto;background:rgba(34,24,26,.8)}" +
        ".eaf-box{width:100%;max-width:440px;padding:22px;border-radius:10px;background:#fff;color:#22181a;font-family:inherit;box-shadow:0 12px 32px rgba(0,0,0,.3)}" +
        ".eaf-box h3{margin:0 0 4px;font-size:1.25rem;color:var(--red,#c41e3a)}.eaf-box p{margin:0}" +
        ".eaf-intro{color:#5b5457;font-size:.92rem;margin-bottom:12px!important}" +
        ".eaf-cam{position:relative;aspect-ratio:4/3;overflow:hidden;border-radius:8px;background:#111}" +
        ".eaf-cam video{width:100%;height:100%;object-fit:cover;transform:scaleX(-1)}" +
        ".eaf-ring{position:absolute;inset:10% 24%;border:3px dashed rgba(255,255,255,.75);border-radius:50%;transition:border-color .2s}" +
        ".eaf-ring.ok{border-style:solid;border-color:#25d366}" +
        ".eaf-msg{min-height:3em;margin:12px 0 8px!important;font-weight:600}" +
        ".eaf-steps{display:flex;flex-wrap:wrap;gap:8px;margin:0;padding:0;list-style:none;font-size:.85rem}" +
        ".eaf-steps li{padding:4px 10px;border:1px solid #e8dfe0;border-radius:999px;background:#f7f3f3}" +
        ".eaf-steps li.done{border-color:#1b7a3d;background:#e6f4ea;color:#14532d;font-weight:600}" +
        ".eaf-actions{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:10px;margin-top:16px}" +
        ".eaf-btn{min-height:44px;padding:10px 20px;border:2px solid var(--red,#c41e3a);border-radius:6px;background:var(--red,#c41e3a);color:#fff;font:inherit;font-weight:600;cursor:pointer}" +
        ".eaf-btn.alt{background:#fff;color:var(--red,#c41e3a)}.eaf-btn:focus-visible{outline:3px solid #22181a;outline-offset:2px}" +
        "@media (prefers-reduced-motion:reduce){.eaf-ring{transition:none}}";

    function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text) e.textContent = text; return e; }

    // Live camera check: look straight, turn the head both ways, look straight again.
    // The head turn stops someone holding up a printed photo or a picture on a phone.
    // Resolves with the face template; rejects with err.cancelled = true if the candidate closes it.
    function capture(opts) {
        opts = opts || {};
        if (!document.getElementById("eaf-css")) { var st = el("style"); st.id = "eaf-css"; st.textContent = css; document.head.appendChild(st); }
        var wrap = el("div", "eaf-wrap"), box = el("div", "eaf-box");
        box.setAttribute("role", "dialog"); box.setAttribute("aria-modal", "true"); box.setAttribute("aria-labelledby", "eaf-title");
        var h = el("h3", "", opts.title || "Face check"); h.id = "eaf-title";
        var cam = el("div", "eaf-cam"), video = el("video"), ring = el("div", "eaf-ring");
        video.autoplay = video.muted = video.playsInline = true; video.setAttribute("playsinline", "");
        cam.appendChild(video); cam.appendChild(ring);
        var msg = el("p", "eaf-msg", "Starting camera..."); msg.setAttribute("aria-live", "polite");
        var steps = el("ol", "eaf-steps"), chips = {};
        [["start", "1. Look straight"], ["turn", "2. Turn left and right"], ["front", "3. Look straight again"]].forEach(function (s) { chips[s[0]] = steps.appendChild(el("li", "", s[1])); });
        var acts = el("div", "eaf-actions"), retry = el("button", "eaf-btn", "Try again"), cancel = el("button", "eaf-btn alt", "Cancel");
        retry.type = cancel.type = "button"; retry.hidden = true;
        acts.appendChild(retry); acts.appendChild(cancel);
        box.appendChild(h); box.appendChild(el("p", "eaf-intro", opts.intro || "Face the camera in good light, with nothing covering your face.")); box.appendChild(cam);
        box.appendChild(msg); box.appendChild(steps); box.appendChild(acts); wrap.appendChild(box); document.body.appendChild(wrap);
        var back = document.activeElement; cancel.focus();

        return new Promise(function (resolve, reject) {
            var stream = null, timer = 0, closed = false, running = false, stage, lo, hi, samples, deadline;
            var detOpts = null;

            function say(t, ok) { if (msg.textContent !== t) msg.textContent = t; ring.classList.toggle("ok", !!ok); }
            function close() {
                closed = true; clearTimeout(timer); document.removeEventListener("keydown", onKey);
                if (stream) stream.getTracks().forEach(function (t) { t.stop(); });
                wrap.remove(); if (back && back.focus) back.focus();
            }
            function stop(t) { running = false; clearTimeout(timer); say(t); retry.hidden = false; retry.focus(); }
            function onKey(e) { if (e.key === "Escape") cancel.click(); }
            document.addEventListener("keydown", onKey);
            cancel.addEventListener("click", function () { close(); var e = new Error("Face check cancelled."); e.cancelled = true; reject(e); });
            // Before the camera has started, Try again restarts the camera too
            retry.addEventListener("click", function () { if (detOpts) return begin(); close(); capture(opts).then(resolve, reject); });

            function begin() {
                stage = "start"; lo = 1; hi = 0; samples = []; deadline = Date.now() + TIMEOUT * 1000;
                Object.keys(chips).forEach(function (k) { chips[k].className = ""; });
                retry.hidden = true; running = true; cancel.focus(); loop();
            }
            function loop() {
                if (closed || !running) return;
                if (Date.now() > deadline) return stop("Time ran out. Tap Try again when you are ready.");
                faceapi.detectAllFaces(video, detOpts).withFaceLandmarks().withFaceDescriptors().then(function (faces) {
                    if (closed || !running) return;
                    handle(faces);
                    if (running) timer = setTimeout(loop, 80);
                }).catch(function () { if (!closed) stop("Something went wrong reading the camera. Tap Try again."); });
            }
            function handle(faces) {
                if (!faces.length) return say("Move your face inside the oval, in good light.");
                if (faces.length > 1) return say("Only one person should be in view.");
                var f = faces[0], y = yaw(f.landmarks);
                // The same person must stay in view for the whole check (a turned face reads a little differently, so looser)
                if (samples.length && distance(samples[0], f.descriptor) > (stage === "turn" ? 0.6 : 0.45)) return stop("A different face appeared during the check. Tap Try again.");
                if (stage === "turn") {
                    lo = Math.min(lo, y); hi = Math.max(hi, y);
                    if (lo < 0.5 - TURN && hi > 0.5 + TURN) { chips.turn.className = "done"; stage = "front"; return say("Good. Now look straight at the camera again."); }
                    return say(lo < 0.5 - TURN || hi > 0.5 + TURN ? "Now turn your head slowly the other way." : "Slowly turn your head to the left, then to the right.", true);
                }
                if (Math.abs(y - 0.5) > 0.08) return say("Look straight at the camera.");
                samples.push(Array.prototype.slice.call(f.descriptor));
                if (stage === "start") { chips.start.className = "done"; stage = "turn"; return say("Slowly turn your head to the left, then to the right.", true); }
                if (samples.length >= 3) {
                    chips.front.className = "done"; running = false; say("Done. Thank you.", true);
                    var d = average(samples);
                    setTimeout(function () { close(); resolve(d); }, 500);
                }
            }

            if (!window.isSecureContext) return stop("The camera only works when this page is opened over https://.");
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return stop("This browser cannot use the camera. Please try Chrome, Safari or Firefox.");
            navigator.mediaDevices.getUserMedia({ video: { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 } }, audio: false })
                .then(function (s) {
                    if (closed) { s.getTracks().forEach(function (t) { t.stop(); }); return; }
                    stream = s; video.srcObject = s;
                    say("Loading face check...");
                    return Promise.all([load(), video.play()]);
                })
                .then(function () {
                    if (closed || !stream) return;
                    detOpts = new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 });
                    begin();
                })
                .catch(function (e) {
                    if (closed) return;
                    var n = e && e.name;
                    stop(n === "NotAllowedError" ? "Camera permission was blocked. Allow the camera for this site in your browser settings, then tap Try again."
                        : n === "NotFoundError" || n === "OverconstrainedError" ? "No camera was found on this device."
                        : n === "NotReadableError" ? "The camera is being used by another app. Close it, then tap Try again."
                        : (e && e.message) || "The camera could not start.");
                });
        });
    }

    // Live check, then compare with a saved template: resolves { match, distance, descriptor }
    function verify(saved, opts) {
        return capture(opts).then(function (d) {
            var dist = distance(saved, d);
            return { match: dist <= MATCH, distance: Math.round(dist * 1000) / 1000, descriptor: d };
        });
    }

    // Same-device storage, only for trying face login out without the Google Sheet backend
    function key(id) { return "ea-face:" + String(id || "").trim().toLowerCase(); }
    function saveLocal(id, d) { try { localStorage.setItem(key(id), JSON.stringify(d)); } catch (e) {} }
    function getLocal(id) { try { return JSON.parse(localStorage.getItem(key(id)) || "null"); } catch (e) { return null; } }

    window.EAFace = { load: load, fromImage: fromImage, capture: capture, verify: verify, distance: distance,
        saveLocal: saveLocal, getLocal: getLocal, MATCH: MATCH, PHOTO_MATCH: PHOTO_MATCH };
})();
